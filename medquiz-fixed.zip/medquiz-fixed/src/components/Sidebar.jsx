import { NavLink, useLocation } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { api } from '../utils/api'

function ProfileModal({ user, onClose, addToast }) {
    const [tab, setTab] = useState('info')
    const [oldPassword, setOldPassword] = useState('')
    const [newPassword, setNewPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [loading, setLoading] = useState(false)

    const handleChangePassword = async () => {
        if (!oldPassword || !newPassword || !confirmPassword)
            return addToast('All fields are required', 'error')
        if (newPassword !== confirmPassword)
            return addToast('New passwords do not match', 'error')
        if (newPassword.length < 6)
            return addToast('Password must be at least 6 characters', 'error')
        setLoading(true)
        try {
            await api.changePassword({ oldPassword, newPassword })
            addToast('Password changed successfully!', 'success')
            setOldPassword(''); setNewPassword(''); setConfirmPassword('')
            onClose()
        } catch (err) {
            addToast(err.message, 'error')
        } finally {
            setLoading(false)
        }
    }

    const joinedDate = user?.created_at
        ? new Date(user.created_at).toLocaleDateString('en-AU', { year: 'numeric', month: 'long', day: 'numeric' })
        : '—'

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal" style={{ maxWidth: 420 }} onClick={e => e.stopPropagation()}>
                <div className="modal-header">
                    <h3>👤 My Account</h3>
                    <button className="btn btn-ghost btn-icon" onClick={onClose}>✕</button>
                </div>
                <div style={{ padding: '1.5rem 1.5rem 0', textAlign: 'center' }}>
                    <div style={{
                        width: 72, height: 72, borderRadius: '50%', margin: '0 auto 0.75rem',
                        background: 'linear-gradient(135deg, var(--accent-blue), var(--accent-purple))',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: '2rem', fontWeight: 700, color: 'white',
                        boxShadow: '0 0 24px rgba(59,130,246,0.3)'
                    }}>
                        {(user?.username || 'U')[0].toUpperCase()}
                    </div>
                    <div style={{ fontWeight: 700, fontSize: '1.1rem' }}>{user?.username || '—'}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>Member since {joinedDate}</div>
                    {user?.role === 'admin' && <span className="pill blue" style={{ marginTop: '0.4rem', display: 'inline-flex' }}>Admin</span>}
                </div>
                <div style={{ padding: '1rem 1.5rem 0' }}>
                    <div className="tabs" style={{ marginBottom: 0 }}>
                        <button className={`tab ${tab === 'info' ? 'active' : ''}`} onClick={() => setTab('info')}>ℹ️ Info</button>
                        <button className={`tab ${tab === 'password' ? 'active' : ''}`} onClick={() => setTab('password')}>🔒 Password</button>
                    </div>
                </div>
                <div className="modal-body">
                    {tab === 'info' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                            {[['Username', user?.username], ['Account Type', user?.role || 'user'], ['Member Since', joinedDate]].map(([label, val]) => (
                                <div key={label} style={{ background: 'var(--bg-input)', borderRadius: 8, padding: '0.75rem 1rem' }}>
                                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '0.2rem' }}>{label}</div>
                                    <div style={{ fontWeight: 600, textTransform: label === 'Account Type' ? 'capitalize' : 'none' }}>{val}</div>
                                </div>
                            ))}
                        </div>
                    )}
                    {tab === 'password' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                            {[['Current Password', oldPassword, setOldPassword], ['New Password', newPassword, setNewPassword], ['Confirm New Password', confirmPassword, setConfirmPassword]].map(([label, val, setter]) => (
                                <div key={label} className="form-group" style={{ marginBottom: 0 }}>
                                    <label className="form-label">{label}</label>
                                    <input type="password" className="input" placeholder={label === 'New Password' ? 'Min. 6 characters' : `Enter ${label.toLowerCase()}`} value={val} onChange={e => setter(e.target.value)} />
                                </div>
                            ))}
                            <button className="btn btn-primary" onClick={handleChangePassword} disabled={loading} style={{ marginTop: '0.25rem' }}>
                                {loading ? 'Updating…' : '🔒 Change Password'}
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

export default function Sidebar({ addToast }) {
    const location = useLocation()
    const [reviewStats, setReviewStats] = useState({ starred: 0, wrong: 0, reviewDue: 0 })
    const [isMobileOpen, setIsMobileOpen] = useState(false)
    const [showProfile, setShowProfile] = useState(false)
    const [user, setUser] = useState(null)

    useEffect(() => {
        api.getReviewStats().then(setReviewStats).catch(() => { })
        api.getMe().then(setUser).catch(() => { })
    }, [location.pathname])

    useEffect(() => { setIsMobileOpen(false) }, [location.pathname])

    const handleLogout = () => {
        localStorage.removeItem('medquiz_token')
        window.location.href = '/'
    }

    return (
        <>
            {/* Mobile hamburger */}
            <button className="mobile-menu-btn" onClick={() => setIsMobileOpen(true)} aria-label="Open menu">
                <span /><span /><span />
            </button>

            {/* Mobile backdrop */}
            {isMobileOpen && <div className="sidebar-overlay" onClick={() => setIsMobileOpen(false)} />}

            {/* Sidebar */}
            <aside className={`sidebar ${isMobileOpen ? 'mobile-open' : ''}`}>
                <div className="sidebar-logo">
                    <div className="sidebar-logo-icon">🏥</div>
                    <h1>MedQuiz</h1>
                    <button className="sidebar-close-btn" onClick={() => setIsMobileOpen(false)} aria-label="Close menu">✕</button>
                </div>

                <nav className="sidebar-nav">
                    <div className="sidebar-section">
                        <div className="sidebar-section-title">Main</div>
                        <NavLink to="/" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`} end>
                            <span className="icon">📊</span> Dashboard
                        </NavLink>
                    </div>
                    <div className="sidebar-section">
                        <div className="sidebar-section-title">Review</div>
                        <NavLink to="/review?filter=starred" className={({ isActive }) => `sidebar-link ${location.search.includes('starred') && isActive ? 'active' : ''}`}>
                            <span className="icon">⭐</span> Starred
                            {reviewStats.starred > 0 && <span className="badge">{reviewStats.starred}</span>}
                        </NavLink>
                        <NavLink to="/review?filter=wrong" className={({ isActive }) => `sidebar-link ${location.search.includes('wrong') && isActive ? 'active' : ''}`}>
                            <span className="icon">❌</span> Wrong Answers
                            {reviewStats.wrong > 0 && <span className="badge" style={{ background: '#ef4444' }}>{reviewStats.wrong}</span>}
                        </NavLink>
                        <NavLink to="/review?filter=review" className={({ isActive }) => `sidebar-link ${location.search.includes('filter=review') ? 'active' : ''}`}>
                            <span className="icon">🔄</span> Spaced Review
                            {reviewStats.reviewDue > 0 && <span className="badge" style={{ background: '#f59e0b' }}>{reviewStats.reviewDue}</span>}
                        </NavLink>
                    </div>
                    <div className="sidebar-section">
                        <div className="sidebar-section-title">System</div>
                        <NavLink to="/settings" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
                            <span className="icon">⚙️</span> Settings
                        </NavLink>
                    </div>
                </nav>

                <div className="sidebar-footer">
                    <button className="sidebar-profile-btn" onClick={() => setShowProfile(true)}>
                        <div className="sidebar-avatar">{(user?.username || 'U')[0].toUpperCase()}</div>
                        <div className="sidebar-profile-info">
                            <div className="sidebar-profile-name">{user?.username || 'Loading…'}</div>
                            <div className="sidebar-profile-role">View profile & settings</div>
                        </div>
                        <span style={{ opacity: 0.5, fontSize: '0.8rem' }}>›</span>
                    </button>
                    <button onClick={handleLogout} className="btn btn-outline btn-sm" style={{ width: '100%', marginTop: '0.5rem', color: 'var(--text-secondary)', gap: '0.5rem' }}>
                        <span>🚪</span> Sign Out
                    </button>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', textAlign: 'center', marginTop: '0.75rem' }}>MedQuiz v1.0 • Built for Excellence</div>
                </div>
            </aside>

            {showProfile && <ProfileModal user={user} onClose={() => setShowProfile(false)} addToast={addToast || (() => { })} />}
        </>
    )
}
